﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentApplicationUsingDapper.ViewModel
{
    public abstract class BaseEntity
    {
    }
}
