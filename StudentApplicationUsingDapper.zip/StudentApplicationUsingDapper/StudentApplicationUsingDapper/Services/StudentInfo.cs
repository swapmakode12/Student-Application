﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using StudentApplicationUsingDapper.ViewModel;
using StudentApplicationUsingDapper.Repository;
using StudentApplicationUsingDapper.Services;

namespace StudentApplicationUsingDapper.Services
{
    public class StudentInfo : IStudentInfoService
    {
        private readonly IStudentInfoRepository _StudentInfoRepository;

        public StudentInfo(IStudentInfoRepository StudentInfoRepository)
        {
            _StudentInfoRepository = StudentInfoRepository;
        }

        public async Task<List<Student>> GetAllStudent()
        {
            return await _StudentInfoRepository.GetAllAsync();
        }

        public async Task<Student> GetStudentInfoById(int id)
        {
            return await _StudentInfoRepository.GetByIdAsync(id);
        }

        public async Task<int> CreateStudentInfoAsync(Student student)
        {
            return await _StudentInfoRepository.CreateAsync(student);
        }

        public async Task<int> UpdateStudentInfoAsync(Student student)
        {
            return await _StudentInfoRepository.UpdateAsync(student);
        }

        public async Task<int> DeleteStudentInfoAsync(Student student)
        {
            return await _StudentInfoRepository.DeleteAsync(student);
        }
    }
}
