﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using StudentApplicationUsingDapper.ViewModel;

namespace StudentApplicationUsingDapper.Services
{
    public interface IStudentInfoService
    {
        public Task<List<Student>> GetAllStudent();
        public Task<Student> GetStudentInfoById(int id);
        public Task<int> CreateStudentInfoAsync(Student product);
        public Task<int> UpdateStudentInfoAsync(Student product);
        public Task<int> DeleteStudentInfoAsync(Student product);
    }
}
