﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using StudentApplicationUsingDapper.ViewModel;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace StudentApplicationUsingDapper.Repository
{
    public class StudentInfoRepository : BaseRepository, IStudentInfoRepository
    {
        public StudentInfoRepository(IConfiguration configuration) : base(configuration)
        { 
        }
         
        public async Task<List<Student>> GetAllAsync()
        {
            try
            {
                var query = "SELECT * FROM StudentInfo";
                using (var connection = CreateConnection())
                {
                    return (await connection.QueryAsync<Student>(query)).ToList();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<Student> GetByIdAsync(int id)
        {
            try
            {
                var query = "SELECT * FROM StudentInfo WHERE StudentId = @StudentId";

                var parameters = new DynamicParameters();
                parameters.Add("StudentId", id, DbType.Int64);

                using (var connection = CreateConnection())
                {
                    return (await connection.QueryFirstOrDefaultAsync<Student>(query, parameters));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<int> CreateAsync(Student entity)
        {
            try
            {
                var query = "INSERT INTO StudentInfo (StudentName,Address,ContactNo,MobileNo,DOB,Gender,Email) VALUES (@StudentName, @Address, @ContactNo,@MobileNo,@DOB,@Gender,@Email)";
                var parameters = new DynamicParameters();
                parameters.Add("StudentName", entity.StudentName, DbType.String);
                parameters.Add("Address", entity.Address, DbType.String);
                parameters.Add("ContactNo", entity.ContactNo, DbType.String);
                parameters.Add("MobileNo", entity.MobileNo, DbType.String);
                parameters.Add("DOB", entity.DOB, DbType.DateTime);
                parameters.Add("Gender", entity.Gender, DbType.String);
                parameters.Add("Email", entity.Email, DbType.String);

                using (var connection = CreateConnection())
                {
                    return (await connection.ExecuteAsync(query, parameters));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<int> UpdateAsync(Student entity)
        {
            try
            {
                var query = "UPDATE StudentInfo SET StudentName = @StudentName, Address = @Address, ContactNo = @ContactNo,MobileNo=@MobileNo,DOB=@DOB,Gender=@Gender,Email=@Email WHERE StudentId = @StudentId";

                var parameters = new DynamicParameters();
                parameters.Add("StudentName", entity.StudentName, DbType.String);
                parameters.Add("Address", entity.Address, DbType.String);
                parameters.Add("ContactNo", entity.ContactNo, DbType.String);
                parameters.Add("MobileNo", entity.MobileNo, DbType.String);
                parameters.Add("DOB", entity.DOB, DbType.DateTime);
                parameters.Add("Gender", entity.Gender, DbType.String);
                parameters.Add("Email", entity.Email, DbType.String);
                parameters.Add("StudentId", entity.StudentId, DbType.Int64);

                using (var connection = CreateConnection())
                {
                    return (await connection.ExecuteAsync(query, parameters));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }

        public async Task<int> DeleteAsync(Student entity)
        {
            try
            {
                var query = "DELETE FROM StudentInfo WHERE StudentId = @StudentId";

                var parameters = new DynamicParameters();
                parameters.Add("StudentId", entity.StudentId, DbType.Int64);

                using (var connection = CreateConnection())
                {
                    return (await connection.ExecuteAsync(query, parameters));
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }
    }
}
