﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using StudentApplicationUsingDapper.ViewModel;

namespace StudentApplicationUsingDapper.Repository
{
    public interface IStudentInfoRepository : IRepository<Student>
    {
    }
}
