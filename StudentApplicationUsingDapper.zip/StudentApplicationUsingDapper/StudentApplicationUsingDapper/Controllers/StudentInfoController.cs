﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using StudentApplicationUsingDapper.Repository;
using StudentApplicationUsingDapper.Services;
using StudentApplicationUsingDapper.ViewModel;

namespace StudentApplicationUsingDapper.Controllers
{
    public class StudentInfoController : Controller
    {
        private readonly IStudentInfoService _StudentInfoService;

        public StudentInfoController(IStudentInfoService productService)
        {
            _StudentInfoService = productService;
        }

        public async Task<IActionResult> Index()
        {
            return View(await _StudentInfoService.GetAllStudent());
        }       

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Student student)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    await _StudentInfoService.CreateStudentInfoAsync(student);
                    return RedirectToAction(nameof(Index));
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Unable to save changes. " +
                                             "Try again, and if the problem persists " +
                                             "see your system administrator.");
            }
            return View(student);
        }

        public async Task<IActionResult> Edit(int id)
        {
            return View(await _StudentInfoService.GetStudentInfoById(id));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Student student)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var dbStudentInfo = await _StudentInfoService.GetStudentInfoById(id);
                    if (await TryUpdateModelAsync<Student>(dbStudentInfo))
                    {
                        await _StudentInfoService.UpdateStudentInfoAsync(dbStudentInfo);
                        return RedirectToAction(nameof(Index));
                    } 
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Unable to save changes. " +
                                             "Try again, and if the problem persists " +
                                             "see your system administrator.");
            }
            return View(student);
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var dbStudentInfo = await _StudentInfoService.GetStudentInfoById(id);
                if (dbStudentInfo != null)
                {
                    await _StudentInfoService.DeleteStudentInfoAsync(dbStudentInfo); 
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Unable to delete. " +
                                             "Try again, and if the problem persists " +
                                             "see your system administrator.");
            }

            return RedirectToAction(nameof(Index));
        }
    } 
}
